<?php
  
add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles' );
function theme_enqueue_styles() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array('parent-style')
    );
    wp_enqueue_style( 'child-style-responsive',get_stylesheet_directory_uri() . 'css/responsive.css', array('parent-style-1'));
}
// silencer script
function jquery_migrate_silencer() {
    // create function copy
    $silencer = '<script>window.console.logger = window.console.log; ';
    // modify original function to filter and use function copy
    $silencer .= 'window.console.log = function(tolog) {';
    // bug out if empty to prevent error
    $silencer .= 'if (tolog == null) {return;} ';
    // filter messages containing string
    $silencer .= 'if (tolog.indexOf("Migrate is installed") == -1) {';
    $silencer .= 'console.logger(tolog);} ';
    $silencer .= '}</script>';
    return $silencer;
}

// for the frontend, use script_loader_tag filter
add_filter('script_loader_tag','jquery_migrate_load_silencer', 10, 2);
function jquery_migrate_load_silencer($tag, $handle) {
    if ($handle == 'jquery-migrate') {
        $silencer = jquery_migrate_silencer();
        // prepend to jquery migrate loading
        $tag = $silencer.$tag;
    }
    return $tag;
}

// for the admin, hook to admin_print_scripts
add_action('admin_print_scripts','jquery_migrate_echo_silencer');
function jquery_migrate_echo_silencer() {echo jquery_migrate_silencer();}

/******* ADD logo **********/
function gootheme_theme_customizer( $wp_customize ) {

    $wp_customize->add_section( 'gootheme_logo_section' , array(
    	'title'       => __( 'Logo', 'gootheme' ),
    	'priority'    => 30,
    	'description' => 'Upload a logo for this theme',
	) );

	$wp_customize->add_setting( 'gootheme_logo', array(
		'default' => get_bloginfo('template_directory') . '/images/default-logo.png',
	) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'gootheme_logo', array(
	
    	'label'    => __( 'Current logo', 'gootheme' ),
		'section'  => 'gootheme_logo_section',
		'settings' => 'gootheme_logo',
	) ) );	
}

add_filter('woocommerce_available_payment_gateways', 'woocs_filter_gateways', 1);
 
function woocs_filter_gateways($gateway_list)
{
    if (WC()->cart->subtotal > 5000)
    {
        unset($gateway_list['cod']);
    }
 
    return $gateway_list;
}

/*add_filter( 'woocommerce_paypal_supported_currencies', 'add_kap_paypal_valid_currency' );
function add_kap_paypal_valid_currency( $currencies ) {
array_push ( $currencies , 'INR' );
return $currencies;
}
add_filter( 'woocommerce_currencies', 'add_inr_currency' );
add_filter( 'woocommerce_currency_symbol', 'add_inr_currency_symbol' );

function add_inr_currency( $currencies ) {
    $currencies['INR'] = 'INR';
    return $currencies;
}

function add_inr_currency_symbol( $symbol ) {
	$currency = get_option( 'woocommerce_currency' );
	switch( $currency ) {
		case 'INR': $symbol = 'Rs.'; break;
	}
	return $symbol;
}*/

/*function Out_of_stock( $is_visible, $id ) {
    $product = new wC_Product( $id );
 
    if ( ! $product->is_in_stock() && ! $product->backorders_allowed() ) {
        $is_visible = false;
    }
 
    return $is_visible;
}
add_filter( 'woocommerce_product_is_visible', 'Out_of_stock', 10, 2 );
*/
function exclude_widget_categories($args){
    $exclude = "31";
    $args["exclude"] = $exclude;
    return $args;
}
add_filter("widget_categories_args","exclude_widget_categories");

function my_remove_schedule_delete() {
    remove_action( 'wp_scheduled_delete', 'wp_scheduled_delete' );
}
add_action( 'init', 'my_remove_schedule_delete' );

//register sidebar

function wpb_widgets_init() {
 
   
    register_sidebar( array(
        'name' =>__( 'Front page Top Banner', 'wpb'),
        'id' => 'widget-product-top',
        'description' => __( 'Appears on the static front Banner', 'wpb' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );
    }
 
add_action( 'widgets_init', 'wpb_widgets_init' );
