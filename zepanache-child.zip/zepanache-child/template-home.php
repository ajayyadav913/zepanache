<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * Template Name: Home NEw
 * @package 8Store Lite
 */

get_header(); ?>
<link rel="stylesheet" id="bootstrap-css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" type="text/css" media="all">
<link href="https://db.onlinewebfonts.com/c/33bc06ea126d3ff79886277122f1f510?family=Brush+Script+MT" rel="stylesheet" type="text/css"/>

<div id="primary" class="content-area">
	<main id="main" class="site-main" role="main">
       <section id="section-product-top2" class='clear store-wrapper'>
                 <?php dynamic_sidebar('widget-product-top'); ?>  

       </section>
		<?php
		//product section 1
	if(is_active_sidebar('widget-product-1')){
		?>
		<section id="section-product1" class='clear'>

			<div class="store-wrapper">
                       
				<?php dynamic_sidebar('widget-product-1'); ?>
			</div>
		</section>
		<?php
	}
		//promotional section 1
	if(is_active_sidebar('widget-promo-1')){
		?>
		<section id="section-promo1" class='clear'>
			<div class="video-cta">
				<?php dynamic_sidebar('widget-promo-1'); ?>
			</div>
		</section>
		<?php
	}
		//Category + Product section 1
	if(is_active_sidebar('widget-category-1')){
		?>
		<section id="section-category1" class='clear'>
			<div class="store-wrapper">
				<?php dynamic_sidebar('widget-category-1'); ?>
			</div>
		</section>
		<?php
	}?>
		<?php
		//load slider
		//do_action('eightstore_lite_homepage_slider'); 
		
		//block below slider
		$eightstore_lite_category_promo_setting_category = get_theme_mod('es_category_promo_setting_category');
		if(!empty($eightstore_lite_category_promo_setting_category)){
			?>
		
	<section id="section-below-slider" class="contaner">
				<div class="store-wrapper">
					
		<div class="categories_grid">
			<?php $i=1;
	$prod_categories = get_terms( 'product_cat', array(
        'orderby'    => 'name',
        'posts_per_page' => 2,
        'order'      => 'ASC',
        'hide_empty' => true
    ));
	 foreach( $prod_categories as $prod_cat ) :
        $cat_thumb_id = get_woocommerce_term_meta( $prod_cat->term_id, 'thumbnail_id', true );
        $shop_catalog_img = wp_get_attachment_image_src( $cat_thumb_id, 'shop_catalog' );
        $term_link = get_term_link( $prod_cat, 'product_cat' );
       
        ?>
         <? if ($i<=5):?> 
         <?if($i==1):?>
			<div class="category_two_cat_1 t1">
				 <div class="category_four_cat_2">
					 	 	<div class="category_grid_box">
					 	 		<?php
										$image = wp_get_attachment_image_src( $cat_thumb_id, 'eightstore-promo-large', false );
										?>
					 	 		 <span class="category_item_bkg" style="background-image:url(<?php echo esc_url($image[0]); ?>)"></span> 
					 	 		 <a href="<?php echo $term_link; ?>" class="category_item">
					 	 		 	 <span class="category_name"><?php echo $prod_cat->name; ?></span> </a>
					 	 		 </div>
					 	 		 </div>
					 	 		 <?elseif($i==2):?>
					 	 		  <div class="category_four_cat_2">
					 	 	<div class="category_grid_box">
					 	 		<?php
										$image = wp_get_attachment_image_src( $cat_thumb_id, 'eightstore-promo-large', false );
										?>
					 	 		 <span class="category_item_bkg" style="background-image:url(<?php echo esc_url($image[0]); ?>)"></span> 
					 	 		 <a href="<?php echo $term_link; ?>" class="category_item"> 
					 	 		 	<span class="category_name"><?php echo $prod_cat->name; ?></span> </a>
					 	 		 </div>
					 	 		 </div>
					 	 		 <?elseif($i==3):?>
					 	 		  <div class="category_four_cat_2">
					 	 	<div class="category_grid_box">
					 	 		<?php
										$image = wp_get_attachment_image_src( $cat_thumb_id, 'eightstore-promo-large', false );
										?>
					 	 		 <span class="category_item_bkg" style="background-image:url(<?php echo esc_url($image[0]); ?>)"></span> 
					 	 		 <a href="<?php echo $term_link; ?>" class="category_item"> 
					 	 		 	<span class="category_name"><?php echo $prod_cat->name; ?></span> </a>
					 	 		 </div>
					 	 		 </div>
					 	 		 <?elseif($i==4):?>
					 	 		  <div class="category_four_cat_2">
					 	 	<div class="category_grid_box">
					 	 		<?php
										$image = wp_get_attachment_image_src( $cat_thumb_id, 'eightstore-promo-large', false );
										?>
					 	 		 <span class="category_item_bkg" style="background-image:url(<?php echo esc_url($image[0]); ?>)"></span> 
					 	 		 <a href="<?php echo $term_link; ?>" class="category_item">
					 	 		 	 <span class="category_name"><?php echo $prod_cat->name; ?></span> </a>
					 	 		 </div>
					 	 		 </div>
					 	 </div>
					 	 <?elseif($i==5):?>
					 	 <div class="category_two_cat_2 t2">
					 	 	<div class="category_grid_box category_grid_box_1">
					 	 		<?php
										$image = wp_get_attachment_image_src( $cat_thumb_id, 'eightstore-promo-large', false );
										?>
					 	 		 <span class="category_item_bkg" style="background-image:url(<?php echo esc_url($image[0]); ?>)"></span> 
					 	 		 <a href="<?php echo $term_link; ?>" class="category_item">
								<span class="category_name"><?php echo $prod_cat->name; ?></span> </a>
					 	 		 </div>
					 	 		 </div>
					 	 		
					 	 		 		 	<? endif;?>
       <? endif;?>
       <? $i++;?>
								<?php endforeach; wp_reset_query();?>
					 	 		 		 	 			 <div class="clearfix"></div>
					 	 		 		 	 			 </div>
					 	 		 		 	 			 </div>
					 	 		 		 	 			 </section>
					 	 		 		 	 			 <?php
	}
	?>
   
		<?php //promotional section 2
	if(is_active_sidebar('widget-promo-2')){
		?>
		<section id="section-promo2" class='clear'>
			<div class="large-cta-block">
				<?php dynamic_sidebar('widget-promo-2'); ?>
			</div>
		</section>
		<?php
	}
		//Category + Product section 2
	if(is_active_sidebar('widget-category-2')){
		?>
		<section id="section-category2" class='clear'>
			<div class="store-wrapper">
				<?php dynamic_sidebar('widget-category-2'); ?>
			</div>
		</section>
		<?php
	}
	
		//promotional section 3
	if(is_active_sidebar('widget-promo-3')){
		?>
		<section id="section-promo3" class='clear'>
			<div class="small-cta-block">
				<?php dynamic_sidebar('widget-promo-3'); ?>
			</div>
		</section>
		<?php
	}
		//product section 2
	if(is_active_sidebar('widget-product-2')){
		?>
		<section id="section-product1" class='clear'>
			<div class="store-wrapper">
				<?php dynamic_sidebar('widget-product-2'); ?>
				<?php echo do_shortcode(get_theme_mod('eightstore_form_shortcode'));?>
			</div>
		</section>
		<?php
	}
	?>
	
	<?php

		//promotional section 4
	if(is_active_sidebar('widget-promo-4')){
		?>
		<section id="section-promo4">
			<div class="store-wrapper">
				<?php dynamic_sidebar('widget-promo-4'); ?>
			</div>
		</section>
		<?php
	}

	?>
<section  id="section-product1" class="store-wrapper">

<h1 style="font-family:Brush Script MT; color:#523e32;font-size: 30px;">Fashionista Diaries</h1>
<div style="padding-top:10px;">
<?php echo do_shortcode('[gs_logo speed="200" ticker="1" inf_loop="0"]'); ?>
</div>


<style>

</style>


</main><!-- #main -->
</div><!-- #primary -->


<?php get_footer(); ?>


